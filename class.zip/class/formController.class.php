<?php

class formController {

	private $tampilIndex;
	private $tampilHalamanDataForm;
	private $ruang;

	public function getHalamanIndex() {
		$this->tampilIndex = new formView();
		$this->tampilIndex->halamanIndex();
	}

	public function getHalamanDataForm() {
		$this->ruang = new formModel();
		$ruangLomba = $this->ruang->ruangRandom();

		$this->tampilHalamanDataForm = new formView();
		$this->tampilHalamanDataForm->halamanDataForm($ruangLomba);
	}
}