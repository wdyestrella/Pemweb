<?php
class formModel {
	public function ruangRandom() {
		$ruang = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
		$acakRuang = $ruang[array_rand($ruang)];
		return $acakRuang;
	}

}